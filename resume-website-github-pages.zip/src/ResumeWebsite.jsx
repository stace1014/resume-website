
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

export default function ResumeWebsite() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Message sent! (This is just a demo)");
    setForm({ name: "", email: "", message: "" });
  };

  const sectionVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <main className="p-6 max-w-4xl mx-auto space-y-10 text-gray-800">
      <motion.header
        className="text-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-5xl font-bold tracking-wide">Stacy Kate Tacuyan</h1>
        <p className="text-lg text-gray-600 mt-2">Business & Education Professional</p>
      </motion.header>

      <motion.section
        className="space-y-4"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={sectionVariants}
      >
        <h1 className="text-4xl font-bold">About Me</h1>
        <p>
          I am a versatile professional with experience in business, education, and
          entrepreneurship. Currently pursuing a Master’s in International Business
          Administration, I enjoy learning, nature, and cultural exploration.
        </p>
      </motion.section>

      <motion.section
        className="space-y-4"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={sectionVariants}
      >
        <h2 className="text-3xl font-semibold">Experience</h2>
        <ul className="space-y-2">
          <li>Freelance Online Instructor</li>
          <li>Foreign Teacher</li>
          <li>Documentation/Reservations Officer</li>
          <li>Self-employed in travel services, stock trading, and rice retailing</li>
        </ul>
      </motion.section>

      <motion.section
        className="space-y-4"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={sectionVariants}
      >
        <h2 className="text-3xl font-semibold">Education</h2>
        <ul className="space-y-2">
          <li>Master’s in International Business Administration (Ongoing)</li>
          <li>MBA</li>
        </ul>
      </motion.section>

      <motion.section
        className="space-y-4"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={sectionVariants}
      >
        <h2 className="text-3xl font-semibold">Skills</h2>
        <ul className="space-y-1 list-disc list-inside">
          <li>Communication & Interpersonal Skills</li>
          <li>Entrepreneurial Mindset</li>
          <li>Adaptability</li>
          <li>Teaching & Mentoring</li>
          <li>Documentation & Administration</li>
        </ul>
      </motion.section>

      <motion.section
        className="space-y-4"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={sectionVariants}
      >
        <h2 className="text-3xl font-semibold">Contact</h2>
        <form className="space-y-4" onSubmit={handleSubmit}>
          <Input
            name="name"
            placeholder="Your Name"
            value={form.name}
            onChange={handleChange}
            required
          />
          <Input
            type="email"
            name="email"
            placeholder="Your Email"
            value={form.email}
            onChange={handleChange}
            required
          />
          <Textarea
            name="message"
            placeholder="Your Message"
            value={form.message}
            onChange={handleChange}
            required
          />
          <Button type="submit">Send</Button>
        </form>
      </motion.section>
    </main>
  );
}
